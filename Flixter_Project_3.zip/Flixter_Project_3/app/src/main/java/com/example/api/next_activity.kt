package com.example.api

import android.R

import android.os.Bundle


import androidx.appcompat.app.AppCompatActivity

class next_activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.example.api.R.layout.activity_next)
    }
}